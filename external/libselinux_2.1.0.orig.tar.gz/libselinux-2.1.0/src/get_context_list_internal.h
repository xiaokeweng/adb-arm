#include <selinux/get_context_list.h>
#include "dso.h"

hidden_proto(get_ordered_context_list)
    hidden_proto(get_ordered_context_list_with_level)
    hidden_proto(get_default_context_with_role)
